﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace ZhupanovVyacheslav__195__3
{
    public class Bitmaps
    {
        public Bitmap DimProductBitmap { get; set; }
        public Bitmap DimResellerBitmap { get; set; }
        public Bitmap DimCurrencyBitmap { get; set; }
        public Bitmap DimPromotionBitmap { get; set; }
        public Bitmap DimSalesTerritoryBitmap { get; set; }
        public Bitmap DimEmployeeBitmap { get; set; }
        public Bitmap DimDateBitmap { get; set; }
        public Bitmap FactResellerSalesBitmap { get; set; }
        public Bitmap CurrencyKeys { get; set; }
        public Bitmap ProductKeys { get; set; }
        public Bitmap ResellerKeys { get; set; }
        public Bitmap PromotionKeys { get; set; }
        public Bitmap SalesTerritoryKeys { get; set; }
        public Bitmap EmployeeKeys { get; set; }
        public Bitmap DateKeys { get; set; }

        public Bitmaps()
        {
            DimCurrencyBitmap = new RoaringBitmap();
            DimDateBitmap = new RoaringBitmap();
            DimEmployeeBitmap = new RoaringBitmap();
            DimProductBitmap = new RoaringBitmap();
            DimPromotionBitmap = new RoaringBitmap();
            DimResellerBitmap = new RoaringBitmap();
            DimSalesTerritoryBitmap = new RoaringBitmap();
            FactResellerSalesBitmap = new RoaringBitmap();
        }
    }

    class InvisibleJoin
    {
        public Bitmap ResBitmap { get; set; }

        public void CreateNewBitmaps(Bitmaps bitmaps, string data_path)
        {
            if (!bitmaps.DimCurrencyBitmap.IsEmpty)
            {
                bitmaps.CurrencyKeys = ParseColumn(data_path + "FactResellerSales.CurrencyKey.csv", bitmaps.DimCurrencyBitmap);
                ResBitmap = bitmaps.CurrencyKeys;
            }
            if (!bitmaps.DimDateBitmap.IsEmpty)
            {
                bitmaps.DateKeys = ParseColumn(data_path + "FactResellerSales.OrderDateKey.csv", bitmaps.DimDateBitmap);
                ResBitmap = bitmaps.DateKeys;
            }
            if (!bitmaps.DimEmployeeBitmap.IsEmpty)
            {
                bitmaps.EmployeeKeys = ParseColumn(data_path + "FactResellerSales.EmployeeKey.csv", bitmaps.DimEmployeeBitmap);
                ResBitmap = bitmaps.EmployeeKeys;
            }
            if (!bitmaps.DimProductBitmap.IsEmpty)
            {
                bitmaps.ProductKeys = ParseColumn(data_path + "FactResellerSales.ProductKey.csv", bitmaps.DimProductBitmap);
                ResBitmap = bitmaps.ProductKeys;
            }
            if (!bitmaps.DimPromotionBitmap.IsEmpty)
            {
                bitmaps.PromotionKeys = ParseColumn(data_path + "FactResellerSales.PromotionKey.csv", bitmaps.DimPromotionBitmap);
                ResBitmap = bitmaps.PromotionKeys;
            }
            if (!bitmaps.DimResellerBitmap.IsEmpty)
            {
                bitmaps.ResellerKeys = ParseColumn(data_path + "FactResellerSales.ResellerKey.csv", bitmaps.DimResellerBitmap);
                ResBitmap = bitmaps.ResellerKeys;
            }
            if (!bitmaps.DimSalesTerritoryBitmap.IsEmpty)
            {
                bitmaps.SalesTerritoryKeys = ParseColumn(data_path + "FactResellerSales.SalesTerritoryKey.csv", bitmaps.DimSalesTerritoryBitmap);
                ResBitmap = bitmaps.SalesTerritoryKeys;
            }
        }

        public Bitmap ParseColumn(string path, Bitmap bitmap)
        {
            Bitmap new_bitmap = new RoaringBitmap();
            using (StreamReader sr = new StreamReader(path))
            {
                string input = sr.ReadLine();
                int i = 1;
                while (input != null)
                {
                    if (bitmap.Get(int.Parse(input)))
                        new_bitmap.Set(i, true);
                    i++;
                    input = sr.ReadLine();
                }
            }
            return new_bitmap;
        }

        public void AndBitmaps(Bitmaps bitmaps)
        {
            if (bitmaps.SalesTerritoryKeys != null)
                ResBitmap.And(bitmaps.SalesTerritoryKeys);
            if (bitmaps.ResellerKeys != null)
                ResBitmap.And(bitmaps.ResellerKeys);
            if (bitmaps.PromotionKeys != null)
                ResBitmap.And(bitmaps.PromotionKeys);
            if (bitmaps.ProductKeys != null)
                ResBitmap.And(bitmaps.ProductKeys);
            if (!bitmaps.FactResellerSalesBitmap.IsEmpty)
                ResBitmap.And(bitmaps.FactResellerSalesBitmap);
            if (bitmaps.EmployeeKeys != null)
                ResBitmap.And(bitmaps.EmployeeKeys);
            if (bitmaps.DateKeys != null)
                ResBitmap.And(bitmaps.DateKeys);
            if (bitmaps.CurrencyKeys != null)
                ResBitmap.And(bitmaps.CurrencyKeys);
        }
    }

    public class MutableArray<T>
    {
        T[] arr;
        int current;

        public int Size() => current;

        public MutableArray(int size = 0)
        {
            arr = new T[size];
            current = 0;
        }

        public void Push(T item, int pos)
        {
            if (pos >= current - 1 || pos == -1)
            {
                Resize();
                arr[current++] = item;
            }
            else
            {
                Resize();
                T[] new_arr = new T[arr.GetLength(0)];
                for (int i = 0; i < pos; i++)
                    new_arr[i] = arr[i];
                new_arr[pos] = item;
                for (int i = pos; i < arr.GetLength(0) - 1; i++)
                    new_arr[i + 1] = arr[i];
                arr = new_arr;
                current++;
            }
        }

        public T Pop(int pos)
        {
            if (pos < 0)
                pos = 0;
            T res = arr[pos];
            Resize();
            T[] new_arr = new T[arr.GetLength(0)];
            for (int i = 0; i < pos; i++)
                new_arr[i] = arr[i];
            for (int i = pos + 1; i < arr.GetLength(0); i++)
                new_arr[i - 1] = arr[i];
            current--;
            arr = new_arr;
            return res;
        }

        private void Resize()
        {
            T[] new_arr = null;
            if (current == arr.GetLength(0))
            {
                if (current == 0)
                    new_arr = new T[1];
                else
                {
                    new_arr = new T[2 * arr.GetLength(0)];
                    for (int i = 0; i < arr.GetLength(0); i++)
                        new_arr[i] = arr[i];
                }
                arr = new_arr;
            }
            else if (arr.GetLength(0) > 1 && current < arr.GetLength(0) / 2)
            {
                new_arr = new T[arr.GetLength(0) / 2];
                for (int i = 0; i < new_arr.GetLength(0); i++)
                    new_arr[i] = arr[i];
                arr = new_arr;
            }
        }

        public T this[int pos]
        {
            get => arr[pos];
            set
            {
                arr[pos] = value;
            }
        }

        public override string ToString()
        {
            string res = "";
            for (int i = 0; i < current; i++)
                res += arr[i] + " ";
            return res;
        }
    }

    public static class Operations
    {
        public static int CountOfBits(ulong numb)
        {
            int res = 0;
            while (numb != 0)
            {
                numb &= (numb - 1);
                res++;
            }
            return res;
        }

        private static int GetIntPosition(int pos) => (int)(64 - pos - 1);

        public static bool GetBit(ulong numb, int pos) => (numb & ((ulong)1 << GetIntPosition(pos))) > 0;


        public static ulong SetBit(ulong numb, int pos, bool value)
        {
            int intPos = GetIntPosition(pos);
            ulong res = numb;
            if (value)
                res |= ((ulong)1 << intPos);
            else
                res &= (~((ulong)1 << intPos));
            return res;
        }
    }

    public abstract class Bitmap
    {
        public MutableArray<DataStore> arr;
        public abstract void And(Bitmap other);
        public abstract void Set(int i, bool value);
        public abstract bool Get(int i);
        public bool IsEmpty { get; set; }
    }

    public class RoaringBitmap : Bitmap
    {
        private const int chunkSize = 1 << 16;

        public RoaringBitmap()
        {
            arr = new MutableArray<DataStore>();
            IsEmpty = true;
        }

        public override void And(Bitmap other)
        {
            while (arr.Size() < other.arr.Size())
                arr.Push(new ArrayDataStore(), -1);
            while (arr.Size() > other.arr.Size())
                other.arr.Push(new ArrayDataStore(), -1);
            for (int i = 0; i < Math.Min(arr.Size(), other.arr.Size()); i++)
                arr[i] = arr[i] & other.arr[i];
        }

        public override bool Get(int numb)
        {
            while (arr.Size() <= numb / chunkSize)
                arr.Push(new ArrayDataStore(), -1);
            return arr[numb / chunkSize].Get(numb % chunkSize);
        }

        public override void Set(int numb, bool value)
        {
            while (arr.Size() <= numb / chunkSize)
                arr.Push(new ArrayDataStore(), -1);
            arr[numb / chunkSize].Set(numb % chunkSize, value);
            IsEmpty = false;
        }
    }

    public abstract class DataStore
    {
        public const int maxValue = 4096;

        public static DataStore operator &(DataStore ds, DataStore ds2)
        {
            if (ds is BitmapDataStore && ds2 is BitmapDataStore)
                return (BitmapDataStore)ds & (BitmapDataStore)ds2;
            else if (ds is BitmapDataStore && ds2 is ArrayDataStore)
                return (BitmapDataStore)ds & (ArrayDataStore)ds2;
            else if (ds is ArrayDataStore && ds2 is BitmapDataStore)
                return (ArrayDataStore)ds & (BitmapDataStore)ds2;
            else
                return (ArrayDataStore)ds & (ArrayDataStore)ds2;
        }

        public abstract int BitCount();
        public abstract bool Get(int num);
        public abstract void Set(int num, bool value);
    }

    public class BitmapDataStore : DataStore
    {
        private MutableArray<ulong> arr;
        private int bit_count;
        private const int unitSize = 64;
        public const int bitmapSize = 1024;

        public BitmapDataStore()
        {
            arr = new MutableArray<ulong>(bitmapSize);
            bit_count = 0;
        }

        public static DataStore operator &(BitmapDataStore ds, BitmapDataStore ds2)
        {
            int k = 0;
            for (int i = 0; i < BitmapDataStore.bitmapSize; i++)
                k += Operations.CountOfBits(ds.arr[i] & ds2.arr[i]);
            if (k > maxValue)
            {
                BitmapDataStore new_bitmap = new BitmapDataStore()
                {
                    bit_count = k
                };
                for (int i = 0; i < BitmapDataStore.bitmapSize; i++)
                    new_bitmap.arr[i] = ds.arr[i] & ds2.arr[i];
                return new_bitmap;
            }
            else
            {
                ArrayDataStore new_bitmap = new ArrayDataStore();
                for (int i = 0; i < BitmapDataStore.bitmapSize; i++)
                {
                    ulong numb = ds.arr[i] & ds2.arr[i];
                    while (numb != 0)
                    {
                        ulong t = numb & ((~numb) + 1);
                        new_bitmap.PushBack(Operations.CountOfBits(t - 1));
                        numb &= (numb - 1);
                    }
                }
                return new_bitmap;
            }
        }

        public static DataStore operator &(BitmapDataStore bds, ArrayDataStore ads)
        {
            ArrayDataStore new_ads = new ArrayDataStore();
            for (int i = 0; i < ads.positions.Size(); i++)
                if (bds.Get(ads.positions[i]))
                    new_ads.PushBack(ads.positions[i]);
            return new_ads;
        }


        public override bool Get(int num)
        {
            int pos = num / unitSize;
            int pos2 = num % unitSize;
            return Operations.GetBit(arr[pos], pos2);
        }

        public override void Set(int numb, bool value)
        {
            int pos = numb / unitSize;
            int pos2 = numb % unitSize;
            if ((!Get(pos)) && value)
                bit_count++;
            if (Get(pos) && (!value))
                bit_count--;
            arr[pos] = Operations.SetBit(arr[pos], pos2, value);
        }

        public override int BitCount() => bit_count;
    }

    public class ArrayDataStore : DataStore
    {
        public MutableArray<int> positions;

        public ArrayDataStore()
        {
            positions = new MutableArray<int>();
        }

        public void PushBack(int item)
        {
            positions.Push(item, -1);
        }

        private int FindPos(int num)
        {
            int a = 0;
            int s = positions.Size();
            while (a + 1 < s)
            {
                int m = (a + s) / 2;
                if (positions[m] <= num)
                    a = m;
                else
                    s = m;
            }
            return a;
        }

        public static DataStore operator &(ArrayDataStore ads, BitmapDataStore bds)
        {
            ArrayDataStore new_arr = new ArrayDataStore();
            for (int i = 0; i < ads.positions.Size(); i++)
                if (bds.Get(ads.positions[i]))
                    new_arr.PushBack(ads.positions[i]);
            return new_arr;
        }

        public static DataStore operator &(ArrayDataStore ads, ArrayDataStore ads2)
        {
            ArrayDataStore new_arr = new ArrayDataStore();
            int pos = 0;
            int pos2 = 0;
            while (pos < ads.positions.Size() && pos2 < ads2.positions.Size())
            {
                if (ads.positions[pos] == ads2.positions[pos2])
                    new_arr.PushBack(ads.positions[pos]);
                if (ads.positions[pos] < ads2.positions[pos2])
                    pos++;
                else
                    pos2++;
            }
            return new_arr;
        }

        public override bool Get(int numb)
        {
            if (positions.Size() == 0)
                return false;
            return positions[FindPos(numb)] == numb;
        }

        public override void Set(int numb, bool value)
        {
            int current_pos = FindPos(numb);
            if (value)
            {
                if (current_pos >= positions.Size() || positions[current_pos] != numb)
                    positions.Push(numb, current_pos + 1);
            }
            else
            {
                if (current_pos < positions.Size() && positions[current_pos] == numb)
                    positions.Pop(current_pos);
            }
        }

        public override int BitCount() => positions.Size();
    }

    public abstract class DimLine
    {
        public string this[string key]
        {
            get
            {
                var prop = GetType().GetProperties();
                var p = prop.FirstOrDefault(x => x.Name == key);
                return p.GetValue(this, null).ToString();
            }
        }

        public abstract string GetName { get; }
        public abstract int GetKey { get; }
    }

    public class DimProduct : DimLine
    {
        public int ProductKey { get; set; }
        public string ProductAlternateKey { get; set; }
        public string EnglishProductName { get; set; }
        public string Color { get; set; }
        public short SafetyStockLevel { get; set; }
        public short ReorderPoint { get; set; }
        public string SizeRange { get; set; }
        public int DaysToManufacture { get; set; }
        public string StartDate { get; set; }

        public override string GetName => "DimProduct";

        public override int GetKey => ProductKey;

        public DimProduct(int productKey, string productAlternateKey, string englishProductName, string color, short safetyStockLevel,
            short reorderPoint, string sizeRange, int daysToManufacture, string startDate)
        {
            ProductKey = productKey;
            ProductAlternateKey = productAlternateKey;
            EnglishProductName = englishProductName;
            Color = color;
            SafetyStockLevel = safetyStockLevel;
            ReorderPoint = reorderPoint;
            SizeRange = sizeRange;
            DaysToManufacture = daysToManufacture;
            StartDate = startDate;
        }
    }

    public class DimReseller : DimLine
    {
        public int ResellerKey { get; set; }
        public string ResellerAlternateKey { get; set; }
        public string Phone { get; set; }
        public string BusinessType { get; set; }
        public string ResellerName { get; set; }
        public int NumberEmployees { get; set; }
        public string OrderFrequency { get; set; }
        public string ProductLine { get; set; }
        public string AddressLine1 { get; set; }
        public string BankName { get; set; }
        public int YearOpened { get; set; }

        public override string GetName => "DimReseller";

        public override int GetKey => ResellerKey;

        public DimReseller(int resellerKey, string resellerAlternateKey, string phone, string businessType, string resellerName,
            int numberEmployees, string orderFrequency, string productLine, string addressLine1, string bankName, int yearOpened)
        {
            ResellerAlternateKey = resellerAlternateKey;
            ResellerKey = resellerKey;
            Phone = phone;
            BusinessType = businessType;
            ResellerName = resellerName;
            NumberEmployees = numberEmployees;
            OrderFrequency = orderFrequency;
            ProductLine = productLine;
            AddressLine1 = addressLine1;
            BankName = bankName;
            YearOpened = yearOpened;
        }
    }

    public class DimCurrency : DimLine
    {
        public int CurrencyKey { get; set; }
        public string CurrencyAlternateKey { get; set; }
        public string CurrencyName { get; set; }

        public override string GetName => "DimCurrency";

        public override int GetKey => CurrencyKey;

        public DimCurrency(int currencyKey, string currencyAlternateKey, string currencyName)
        {
            CurrencyAlternateKey = currencyAlternateKey;
            CurrencyKey = currencyKey;
            CurrencyName = currencyName;
        }
    }

    public class DimPromotion : DimLine
    {
        public int PromotionKey { get; set; }
        public int PromotionAlternateKey { get; set; }
        public string EnglishPromotionName { get; set; }
        public string EnglishPromotionType { get; set; }
        public string EnglishPromotionCategory { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public int MinQty { get; set; }

        public override string GetName => "DimPromotion";

        public override int GetKey => PromotionKey;

        public DimPromotion(int promotionKey, int promotionAlternateKey, string englishPromotionName, string englishPromotionType,
            string englishPromotionCategory, string startDate, string endDate, int minQty)
        {
            PromotionKey = promotionKey;
            PromotionAlternateKey = promotionAlternateKey;
            EnglishPromotionCategory = englishPromotionCategory;
            EnglishPromotionName = englishPromotionName;
            EnglishPromotionType = englishPromotionType;
            StartDate = startDate;
            EndDate = endDate;
            MinQty = minQty;
        }
    }

    public class DimSalesTerritory : DimLine
    {
        public int SalesTerritoryKey { get; set; }
        public int SalesTerritoryAlternateKey { get; set; }
        public string SalesTerritoryRegion { get; set; }
        public string SalesTerritoryCountry { get; set; }
        public string SalesTerritoryGroup { get; set; }

        public override string GetName => "DimSalesTerritory";

        public override int GetKey => SalesTerritoryKey;

        public DimSalesTerritory(int salesTerritoryKey, int salesTerritoryAlternateKey, string salesTerritoryRegion, string salesTerritoryCountry,
            string salesTerritoryGroup)
        {
            SalesTerritoryAlternateKey = salesTerritoryAlternateKey;
            SalesTerritoryCountry = salesTerritoryCountry;
            SalesTerritoryGroup = salesTerritoryGroup;
            SalesTerritoryKey = salesTerritoryKey;
            SalesTerritoryRegion = salesTerritoryRegion;
        }

        public override string ToString() => $"{SalesTerritoryKey} {SalesTerritoryAlternateKey} {SalesTerritoryRegion} {SalesTerritoryCountry} {SalesTerritoryGroup}";
    }

    public class DimEmployee : DimLine
    {
        public int EmployeeKey { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Title { get; set; }
        public string BirthDate { get; set; }
        public string LoginID { get; set; }
        public string EmailAddress { get; set; }
        public string Phone { get; set; }
        public string MaritalStatus { get; set; }
        public string Gender { get; set; }
        public byte PayFrequency { get; set; }
        public short VacationHours { get; set; }
        public short SickLeaveHours { get; set; }
        public string DepartmentName { get; set; }
        public string StartDate { get; set; }

        public override string GetName => "DimEmployee";

        public override int GetKey => EmployeeKey;

        public DimEmployee(int employeeKey, string firstName, string lastName, string title, string birthDate, string loginID,
            string emailAddress, string phone, string maritalStatus, string gender, byte payFrequency, short vacationHours,
            short sickLeaveHours, string departmentName, string startDate)
        {
            EmailAddress = emailAddress;
            EmployeeKey = employeeKey;
            FirstName = firstName;
            LastName = lastName;
            Title = title;
            BirthDate = birthDate;
            LoginID = loginID;
            Phone = phone;
            MaritalStatus = maritalStatus;
            Gender = gender;
            PayFrequency = payFrequency;
            VacationHours = vacationHours;
            SickLeaveHours = sickLeaveHours;
            DepartmentName = departmentName;
            StartDate = startDate;
        }
    }

    public class DimDate : DimLine
    {
        public int DateKey { get; set; }
        public string FullDateAlternateKey { get; set; }
        public byte DayNumberOfWeek { get; set; }
        public string EnglishDayNameOfWeek { get; set; }
        public byte DayNumberOfMonth { get; set; }
        public short DayNumberOfYear { get; set; }
        public byte WeekNumberOfYear { get; set; }
        public string EnglishMonthName { get; set; }
        public byte MonthNumberOfYear { get; set; }
        public byte CalendarQuarter { get; set; }
        public short CalendarYear { get; set; }
        public byte CalendarSemester { get; set; }
        public byte FiscalQuarter { get; set; }
        public short FiscalYear { get; set; }
        public byte FiscalSemester { get; set; }

        public override string GetName => "DimDate";

        public override int GetKey => DateKey;

        public DimDate(int dateKey, string fullDateAlternateKey, byte dayNumberOfWeek, string englishDayNameOfWeek, byte dayNumberOfMonth,
            short dayNumberOfYear, byte weekNumberOfYear, string englishMonthName, byte monthNumberOfYear, byte calendarQuarter, short calendarYear,
            byte calendarSemester, byte fiscalQuarter, short fiscalYear, byte fiscalSemester)
        {
            DateKey = dateKey;
            FullDateAlternateKey = fullDateAlternateKey;
            DayNumberOfWeek = dayNumberOfWeek;
            EnglishDayNameOfWeek = englishDayNameOfWeek;
            DayNumberOfMonth = dayNumberOfMonth;
            DayNumberOfYear = dayNumberOfYear;
            WeekNumberOfYear = weekNumberOfYear;
            EnglishMonthName = englishMonthName;
            MonthNumberOfYear = monthNumberOfYear;
            CalendarQuarter = calendarQuarter;
            CalendarYear = calendarYear;
            CalendarSemester = calendarSemester;
            FiscalQuarter = fiscalQuarter;
            FiscalYear = fiscalYear;
            FiscalSemester = fiscalSemester;
        }
    }

    public class FactResellerSales : DimLine
    {
        public int ProductKey { get; set; }
        public int OrderDateKey { get; set; }
        public int ResellerKey { get; set; }
        public int EmployeeKey { get; set; }
        public int PromotionKey { get; set; }
        public int CurrencyKey { get; set; }
        public int SalesTerritoryKey { get; set; }
        public string SalesOrderNumber { get; set; }
        public byte SalesOrderLineNumber { get; set; }
        public short OrderQuantity { get; set; }
        public string CarrierTrackingNumber { get; set; }
        public string CustomerPONumber { get; set; }

        public override string GetName => "FactResellerSales";

        public override int GetKey => 0;
    }

    public class Table
    {
        List<DimLine> lines;

        public Table(string tablePath, string data_path)
        {
            lines = new List<DimLine>();
            ParseTable(tablePath + ".csv", data_path);
        }

        public string GetName { get; private set; }

        public List<DimLine> GetTable => lines;

        private void DimSalesTerritoryAdd(string path)
        {
            using (StreamReader sr = new StreamReader(path))
            {
                string input = sr.ReadLine();
                while (input != null)
                {
                    string[] characteristics = input.Split('|');
                    lines.Add(new DimSalesTerritory(int.Parse(characteristics[0]), int.Parse(characteristics[1]), characteristics[2], characteristics[3], characteristics[4]));
                    input = sr.ReadLine();
                }
            }
        }

        private void DimEmployeeAdd(string path)
        {
            using (StreamReader sr = new StreamReader(path))
            {
                string input = sr.ReadLine();
                while (input != null)
                {
                    string[] characteristics = input.Split('|');
                    lines.Add(new DimEmployee(int.Parse(characteristics[0]), characteristics[1], characteristics[2], characteristics[3],
                        characteristics[4], characteristics[5], characteristics[6], characteristics[7], characteristics[8], characteristics[9],
                        byte.Parse(characteristics[10]), short.Parse(characteristics[11]), short.Parse(characteristics[12]), characteristics[13],
                        characteristics[14]));
                    input = sr.ReadLine();
                }
            }
        }

        private void DimDateAdd(string path)
        {
            using (StreamReader sr = new StreamReader(path))
            {
                string input = sr.ReadLine();
                while (input != null)
                {
                    string[] characteristics = input.Split('|');
                    lines.Add(new DimDate(int.Parse(characteristics[0]), characteristics[1], byte.Parse(characteristics[2]), characteristics[3],
                        byte.Parse(characteristics[4]), short.Parse(characteristics[5]), byte.Parse(characteristics[6]), characteristics[7],
                        byte.Parse(characteristics[8]), byte.Parse(characteristics[9]), short.Parse(characteristics[10]), byte.Parse(characteristics[11]),
                        byte.Parse(characteristics[12]), short.Parse(characteristics[13]), byte.Parse(characteristics[14])));
                    input = sr.ReadLine();
                }
            }
        }

        private void DimProductAdd(string path)
        {
            using (StreamReader sr = new StreamReader(path))
            {
                string input = sr.ReadLine();
                while (input != null)
                {
                    string[] characteristics = input.Split('|');
                    lines.Add(new DimProduct(int.Parse(characteristics[0]), characteristics[1], characteristics[2], characteristics[3],
                        short.Parse(characteristics[4]), short.Parse(characteristics[5]), characteristics[6], int.Parse(characteristics[7]), characteristics[8]));
                    input = sr.ReadLine();
                }
            }
        }

        private void DimResellerAdd(string path)
        {
            using (StreamReader sr = new StreamReader(path))
            {
                string input = sr.ReadLine();
                while (input != null)
                {
                    string[] characteristics = input.Split('|');
                    lines.Add(new DimReseller(int.Parse(characteristics[0]), characteristics[1], characteristics[2], characteristics[3],
                        characteristics[4], int.Parse(characteristics[5]), characteristics[6], characteristics[7], characteristics[8],
                        characteristics[9], int.Parse(characteristics[10])));
                    input = sr.ReadLine();
                }
            }
        }

        private void DimCurrencyAdd(string path)
        {
            using (StreamReader sr = new StreamReader(path))
            {
                string input = sr.ReadLine();
                while (input != null)
                {
                    string[] characteristics = input.Split('|');
                    lines.Add(new DimCurrency(int.Parse(characteristics[0]), characteristics[1], characteristics[2]));
                    input = sr.ReadLine();
                }
            }
        }

        private void DimPromotionAdd(string path)
        {
            using (StreamReader sr = new StreamReader(path))
            {
                string input = sr.ReadLine();
                while (input != null)
                {
                    string[] characteristics = input.Split('|');
                    lines.Add(new DimPromotion(int.Parse(characteristics[0]), int.Parse(characteristics[1]), characteristics[2], characteristics[3],
                        characteristics[4], characteristics[5], characteristics[6], int.Parse(characteristics[7])));
                    input = sr.ReadLine();
                }
            }
        }

        private void ParseTable(string tablePath, string data_path)
        {
            switch (tablePath)
            {
                case "DimSalesTerritory.csv":
                    DimSalesTerritoryAdd(data_path + tablePath);
                    GetName = "DimSalesTerritory";
                    break;
                case "DimEmployee.csv":
                    DimEmployeeAdd(data_path + tablePath);
                    GetName = "DimEmployee";
                    break;
                case "DimDate.csv":
                    DimDateAdd(data_path + tablePath);
                    GetName = "DimDate";
                    break;
                case "DimProduct.csv":
                    DimProductAdd(data_path + tablePath);
                    GetName = "DimProduct";
                    break;
                case "DimReseller.csv":
                    DimResellerAdd(data_path + tablePath);
                    GetName = "DimReseller";
                    break;
                case "DimCurrency.csv":
                    DimCurrencyAdd(data_path + tablePath);
                    GetName = "DimCurrency";
                    break;
                case "DimPromotion.csv":
                    DimPromotionAdd(data_path + tablePath);
                    GetName = "DimPromotion";
                    break;
            }
        }
    }

    public class Compare
    {
        public void CompareValue((string, string, string, string) comparisonСharacteristics, List<Table> tables, Bitmap bitmap)
        {
            string value = string.Empty;
            if (!int.TryParse(comparisonСharacteristics.Item4, out int x))
            {
                for (int i = 2; i < comparisonСharacteristics.Item4.Length - 1; i++)
                {
                    value += comparisonСharacteristics.Item4[i];
                }
                comparisonСharacteristics.Item4 = value;
            }
            for (int i = 0; i < tables.Count; i++)
            {
                if (comparisonСharacteristics.Item1 == tables[i].GetName)
                {
                    switch (comparisonСharacteristics.Item3)
                    {
                        case "<":
                            foreach (var item in tables[i].GetTable)
                                if (int.Parse(item[comparisonСharacteristics.Item2]) < int.Parse(comparisonСharacteristics.Item4))
                                    bitmap.Set(item.GetKey, true);
                            break;
                        case ">":
                            foreach (var item in tables[i].GetTable)
                                if (int.Parse(item[comparisonСharacteristics.Item2]) > int.Parse(comparisonСharacteristics.Item4))
                                    bitmap.Set(item.GetKey, true);
                            break;
                        case "<=":
                            foreach (var item in tables[i].GetTable)
                                if (int.Parse(item[comparisonСharacteristics.Item2]) <= int.Parse(comparisonСharacteristics.Item4))
                                    bitmap.Set(item.GetKey, true);
                            break;
                        case ">=":
                            foreach (var item in tables[i].GetTable)
                                if (int.Parse(item[comparisonСharacteristics.Item2]) >= int.Parse(comparisonСharacteristics.Item4))
                                    bitmap.Set(item.GetKey, true);
                            break;
                        case "=":
                            {
                                foreach (var item in tables[i].GetTable)
                                    if (item[comparisonСharacteristics.Item2] == comparisonСharacteristics.Item4)
                                        bitmap.Set(item.GetKey, true);
                            }
                            break;
                        case "<>":
                            {
                                foreach (var item in tables[i].GetTable)
                                    if (item[comparisonСharacteristics.Item2] != comparisonСharacteristics.Item4)
                                        bitmap.Set(item.GetKey, true);
                            }
                            break;
                    }
                }
            }
        }

        public void CompareValuesFactResellerSales((string, string, string, string) comparisonСharacteristics, List<FactResellerSales> table, Bitmap bitmap)
        {
            string value = string.Empty;
            if (!int.TryParse(comparisonСharacteristics.Item4, out int x))
            {
                for (int i = 1; i < comparisonСharacteristics.Item4.Length - 1; i++)
                {
                    value += comparisonСharacteristics.Item4[i];
                }
                comparisonСharacteristics.Item4 = value;
            }
            switch (comparisonСharacteristics.Item3)
            {
                case "<":
                    for (int i = 1; i < table.Count; i++)
                        if (int.Parse(table[i][comparisonСharacteristics.Item2]) < int.Parse(comparisonСharacteristics.Item4))
                            bitmap.Set(i, true);
                    break;
                case ">":
                    for (int i = 0; i < table.Count; i++)
                        if (int.Parse(table[i][comparisonСharacteristics.Item2]) > int.Parse(comparisonСharacteristics.Item4))
                            bitmap.Set(i, true);
                    break;
                case "<=":
                    for (int i = 0; i < table.Count; i++)
                        if (int.Parse(table[i][comparisonСharacteristics.Item2]) <= int.Parse(comparisonСharacteristics.Item4))
                            bitmap.Set(i, true);
                    break;
                case ">=":
                    for (int i = 0; i < table.Count; i++)
                        if (int.Parse(table[i][comparisonСharacteristics.Item2]) >= int.Parse(comparisonСharacteristics.Item4))
                            bitmap.Set(i, true);
                    break;
                case "=":
                    for (int i = 0; i < table.Count; i++)
                        if (table[i][comparisonСharacteristics.Item2] == comparisonСharacteristics.Item4)
                            bitmap.Set(i, true);
                    break;
                case "<>":
                    for (int i = 0; i < table.Count; i++)
                        if (table[i][comparisonСharacteristics.Item2] != comparisonСharacteristics.Item4)
                            bitmap.Set(i, true);
                    break;
            }
        }
    }

    class Output
    {
        string outputString;
        public void CreateOutputString(string outputFotmat, Bitmap resBitmap, string data_path)
        {
            string[] arOutputFotmat = outputFotmat.Split(',');
            List<List<string>> allvalues = new List<List<string>>();
            for (int i = 0; i < arOutputFotmat.Length; i++)
            {
                List<string> value = new List<string>();
                using (StreamReader sr = new StreamReader(data_path + arOutputFotmat[i] + ".csv"))
                {
                    string input = sr.ReadLine();
                    int j = 1;
                    while (input != null)
                    {
                        if (resBitmap.Get(j))
                            value.Add(input);
                        j++;
                        input = sr.ReadLine();
                    }
                }
                allvalues.Add(value);
            }
            List<string> outputRes = allvalues[0];
            for (int i = 1; i < allvalues.Count; i++)
                for (int j = 0; j < allvalues[i].Count; j++)
                    outputRes[j] += "|" + allvalues[i][j];
            for (int i = 0; i < outputRes.Count; i++)
                outputString += outputRes[i] + "\n";
        }

        public void WriteFile(string path)
        {
            using (StreamWriter sw = new StreamWriter(path))
            {
                sw.WriteLine(outputString);
            }
        }
    }

    class Program
    {

        static string OutputFormat { get; set; }
        static (string, string, string, string)[] comparisonСharacteristics;
        static List<FactResellerSales> resellerSales;
        static List<Table> tables;
        static Compare compare;
        static Bitmaps bitmaps;
        static string output_path;
        static string input_path;
        static string data_path;

        static void Main(string[] args)
        {
            if (args.Length == 3)
            {
                CreateInputPath(args[1]);
                CreateOutputPath(args[2]);
                CreateDataPath(args[0]);
                ParseFile(input_path);
                tables = new List<Table>();
                for (int i = 0; i < comparisonСharacteristics.Length; i++)
                {
                    if (comparisonСharacteristics[i].Item1[0] != 'F')
                        tables.Add(new Table(comparisonСharacteristics[i].Item1, data_path));
                    else
                    {
                        if (resellerSales == null)
                        {
                            resellerSales = new List<FactResellerSales>();
                            AddFactResellerSales(i, 0);
                        }
                        else
                            AddFactResellerSales(i, 1);
                    }
                }
                compare = new Compare();
                bitmaps = new Bitmaps();
                AddBitmaps();
                InvisibleJoin join = new InvisibleJoin();
                join.CreateNewBitmaps(bitmaps, data_path);
                join.AndBitmaps(bitmaps);
                Output output = new Output();
                output.CreateOutputString(OutputFormat, join.ResBitmap, data_path);
                output.WriteFile(output_path);
            }
            else
                Console.WriteLine("Что-то не так с аргументами!");
        }

        private static void CreateInputPath(string path)
        {
            if (path[1] != ':')
                input_path = "input\\" + path;
            else
                input_path = path;
        }

        private static void CreateDataPath(string path)
        {
            if (path[1] != ':')
                data_path = "data\\";
            else
                data_path = path + "\\";
        }

        private static void CreateOutputPath(string path)
        {
            if (path[1] != ':')
                output_path = "output\\" + path;
            else
                output_path = path;
        }

        private static void AddBitmaps()
        {
            for (int i = 0; i < comparisonСharacteristics.Length; i++)
            {
                if (comparisonСharacteristics[i].Item1[0] != 'F')
                    switch (comparisonСharacteristics[i].Item1)
                    {
                        case "DimSalesTerritory":
                            compare.CompareValue(comparisonСharacteristics[i], tables, bitmaps.DimSalesTerritoryBitmap);
                            break;
                        case "DimEmployee":
                            compare.CompareValue(comparisonСharacteristics[i], tables, bitmaps.DimEmployeeBitmap);
                            break;
                        case "DimDate":
                            compare.CompareValue(comparisonСharacteristics[i], tables, bitmaps.DimDateBitmap);
                            break;
                        case "DimProduct":
                            compare.CompareValue(comparisonСharacteristics[i], tables, bitmaps.DimProductBitmap);
                            break;
                        case "DimReseller":
                            compare.CompareValue(comparisonСharacteristics[i], tables, bitmaps.DimResellerBitmap);
                            break;
                        case "DimCurrency":
                            compare.CompareValue(comparisonСharacteristics[i], tables, bitmaps.DimCurrencyBitmap);
                            break;
                        case "DimPromotion":
                            compare.CompareValue(comparisonСharacteristics[i], tables, bitmaps.DimPromotionBitmap);
                            break;
                    }
                else
                    compare.CompareValuesFactResellerSales(comparisonСharacteristics[i], resellerSales, bitmaps.FactResellerSalesBitmap);
            }
        }

        private static void AddFactResellerSales(int i, int flag)
        {
            switch (comparisonСharacteristics[i].Item2)
            {
                case "CustomerPONumber":
                    CustomerPONumberAdd(i, flag);
                    break;
                case "CarrierTrackingNumber":
                    CarrierTrackingNumberAdd(i, flag);
                    break;
                case "OrderQuantity":
                    OrderQuantityAdd(i, flag);
                    break;
                case "SalesOrderLineNumber":
                    SalesOrderLineNumberAdd(i, flag);
                    break;
                case "SalesOrderNumber":
                    SalesOrderNumberAdd(i, flag);
                    break;
                case "SalesTerritoryKey":
                    SalesTerritoryKeyAdd(i, flag);
                    break;
                case "CurrencyKey":
                    CurrencyKeyAdd(i, flag);
                    break;
                case "PromotionKey":
                    PromotionKeyAdd(i, flag);
                    break;
                case "EmployeeKey":
                    EmployeeKeyAdd(i, flag);
                    break;
                case "ProductKey":
                    ProductKeyAdd(i, flag);
                    break;
                case "OrderDateKey":
                    OrderDateKeyAdd(i, flag);
                    break;
                case "ResellerKey":
                    ResellerKeyAdd(i, flag);
                    break;
            }
        }

        private static void OrderDateKeyAdd(int i, int flag)
        {
            using (StreamReader sr = new StreamReader(data_path + comparisonСharacteristics[i].Item1 + "." + comparisonСharacteristics[i].Item2 + ".csv"))
            {
                string input = sr.ReadLine();
                if (flag == 0)
                {
                    while (input != null)
                    {
                        FactResellerSales item = new FactResellerSales();
                        item.OrderDateKey = int.Parse(input);
                        resellerSales.Add(item);
                        input = sr.ReadLine();
                    }
                }
                else
                {
                    for (int j = 0; j < resellerSales.Count; j++)
                    {
                        resellerSales[j].OrderDateKey = int.Parse(input);
                        input = sr.ReadLine();
                    }
                }
            }
        }

        private static void ResellerKeyAdd(int i, int flag)
        {
            using (StreamReader sr = new StreamReader(data_path + comparisonСharacteristics[i].Item1 + "." + comparisonСharacteristics[i].Item2 + ".csv"))
            {
                string input = sr.ReadLine();
                if (flag == 0)
                    while (input != null)
                    {
                        FactResellerSales item = new FactResellerSales();
                        item.ResellerKey = int.Parse(input);
                        resellerSales.Add(item);
                        input = sr.ReadLine();
                    }
                else
                {
                    for (int j = 0; j < resellerSales.Count; j++)
                    {
                        resellerSales[j].ResellerKey = int.Parse(input);
                        input = sr.ReadLine();
                    }
                }
            }
        }

        private static void ProductKeyAdd(int i, int flag)
        {
            using (StreamReader sr = new StreamReader(data_path + comparisonСharacteristics[i].Item1 + "." + comparisonСharacteristics[i].Item2 + ".csv"))
            {
                string input = sr.ReadLine();
                if (flag == 0)
                    while (input != null)
                    {
                        FactResellerSales item = new FactResellerSales();
                        item.ProductKey = int.Parse(input);
                        resellerSales.Add(item);
                        input = sr.ReadLine();
                    }
                else
                {
                    for (int j = 0; j < resellerSales.Count; j++)
                    {
                        resellerSales[j].ProductKey = int.Parse(input);
                        input = sr.ReadLine();
                    }
                }
            }
        }

        private static void EmployeeKeyAdd(int i, int flag)
        {
            using (StreamReader sr = new StreamReader(data_path + comparisonСharacteristics[i].Item1 + "." + comparisonСharacteristics[i].Item2 + ".csv"))
            {
                string input = sr.ReadLine();
                if (flag == 0)
                    while (input != null)
                    {
                        FactResellerSales item = new FactResellerSales();
                        item.EmployeeKey = int.Parse(input);
                        resellerSales.Add(item);
                        input = sr.ReadLine();
                    }
                else
                {
                    for (int j = 0; j < resellerSales.Count; j++)
                    {
                        resellerSales[j].EmployeeKey = int.Parse(input);
                        input = sr.ReadLine();
                    }
                }
            }
        }

        private static void PromotionKeyAdd(int i, int flag)
        {
            using (StreamReader sr = new StreamReader(data_path + comparisonСharacteristics[i].Item1 + "." + comparisonСharacteristics[i].Item2 + ".csv"))
            {
                string input = sr.ReadLine();
                if (flag == 0)
                    while (input != null)
                    {
                        FactResellerSales item = new FactResellerSales();
                        item.PromotionKey = int.Parse(input);
                        resellerSales.Add(item);
                        input = sr.ReadLine();
                    }
                else
                {
                    for (int j = 0; j < resellerSales.Count; j++)
                    {
                        resellerSales[j].PromotionKey = int.Parse(input);
                        input = sr.ReadLine();
                    }
                }
            }
        }

        private static void CurrencyKeyAdd(int i, int flag)
        {
            using (StreamReader sr = new StreamReader(data_path + comparisonСharacteristics[i].Item1 + "." + comparisonСharacteristics[i].Item2 + ".csv"))
            {
                string input = sr.ReadLine();
                if (flag == 0)
                    while (input != null)
                    {
                        FactResellerSales item = new FactResellerSales();
                        item.CurrencyKey = int.Parse(input);
                        resellerSales.Add(item);
                        input = sr.ReadLine();
                    }
                else
                {
                    for (int j = 0; j < resellerSales.Count; j++)
                    {
                        resellerSales[j].CurrencyKey = int.Parse(input);
                        input = sr.ReadLine();
                    }
                }
            }
        }

        private static void SalesTerritoryKeyAdd(int i, int flag)
        {
            using (StreamReader sr = new StreamReader(data_path + comparisonСharacteristics[i].Item1 + "." + comparisonСharacteristics[i].Item2 + ".csv"))
            {
                string input = sr.ReadLine();
                if (flag == 0)
                    while (input != null)
                    {
                        FactResellerSales item = new FactResellerSales();
                        item.SalesTerritoryKey = int.Parse(input);
                        resellerSales.Add(item);
                        input = sr.ReadLine();
                    }
                else
                {
                    for (int j = 0; j < resellerSales.Count; j++)
                    {
                        resellerSales[j].SalesTerritoryKey = int.Parse(input);
                        input = sr.ReadLine();
                    }
                }
            }
        }

        private static void SalesOrderNumberAdd(int i, int flag)
        {
            using (StreamReader sr = new StreamReader(data_path + comparisonСharacteristics[i].Item1 + "." + comparisonСharacteristics[i].Item2 + ".csv"))
            {
                string input = sr.ReadLine();
                if (flag == 0)
                    while (input != null)
                    {
                        FactResellerSales item = new FactResellerSales();
                        item.SalesOrderNumber = input;
                        resellerSales.Add(item);
                        input = sr.ReadLine();
                    }
                else
                {
                    for (int j = 0; j < resellerSales.Count; j++)
                    {
                        resellerSales[j].SalesOrderNumber = input;
                        input = sr.ReadLine();
                    }
                }
            }
        }

        private static void SalesOrderLineNumberAdd(int i, int flag)
        {
            using (StreamReader sr = new StreamReader(data_path + comparisonСharacteristics[i].Item1 + "." + comparisonСharacteristics[i].Item2 + ".csv"))
            {
                string input = sr.ReadLine();
                if (flag == 0)
                    while (input != null)
                    {
                        FactResellerSales item = new FactResellerSales();
                        item.SalesOrderLineNumber = byte.Parse(input);
                        resellerSales.Add(item);
                        input = sr.ReadLine();
                    }
                else
                {
                    for (int j = 0; j < resellerSales.Count; j++)
                    {
                        resellerSales[j].SalesOrderLineNumber = byte.Parse(input);
                        input = sr.ReadLine();
                    }
                }
            }
        }

        private static void OrderQuantityAdd(int i, int flag)
        {
            using (StreamReader sr = new StreamReader(data_path + comparisonСharacteristics[i].Item1 + "." + comparisonСharacteristics[i].Item2 + ".csv"))
            {
                string input = sr.ReadLine();
                if (flag == 0)
                    while (input != null)
                    {
                        FactResellerSales item = new FactResellerSales();
                        item.OrderQuantity = short.Parse(input);
                        resellerSales.Add(item);
                        input = sr.ReadLine();
                    }
                else
                {
                    for (int j = 0; j < resellerSales.Count; j++)
                    {
                        resellerSales[j].OrderQuantity = short.Parse(input);
                        input = sr.ReadLine();
                    }
                }
            }
        }

        private static void CarrierTrackingNumberAdd(int i, int flag)
        {
            using (StreamReader sr = new StreamReader(data_path + comparisonСharacteristics[i].Item1 + "." + comparisonСharacteristics[i].Item2 + ".csv"))
            {
                string input = sr.ReadLine();
                if (flag == 0)
                    while (input != null)
                    {
                        FactResellerSales item = new FactResellerSales();
                        item.CarrierTrackingNumber = input;
                        resellerSales.Add(item);
                        input = sr.ReadLine();
                    }
                else
                {
                    for (int j = 0; j < resellerSales.Count; j++)
                    {
                        resellerSales[j].CarrierTrackingNumber = input;
                        input = sr.ReadLine();
                    }
                }
            }
        }

        private static void CustomerPONumberAdd(int i, int flag)
        {
            using (StreamReader sr = new StreamReader(data_path + comparisonСharacteristics[i].Item1 + "." + comparisonСharacteristics[i].Item2 + ".csv"))
            {
                string input = sr.ReadLine();
                if (flag == 0)
                    while (input != null)
                    {
                        FactResellerSales item = new FactResellerSales();
                        item.CustomerPONumber = input;
                        resellerSales.Add(item);
                        input = sr.ReadLine();
                    }
                else
                {
                    for (int j = 0; j < resellerSales.Count; j++)
                    {
                        resellerSales[j].CustomerPONumber = input;
                        input = sr.ReadLine();
                    }
                }
            }
        }

        private static void ParseFile(string path)
        {
            using (StreamReader sr = new StreamReader(path))
            {
                OutputFormat = sr.ReadLine();
                int count = int.Parse(sr.ReadLine());
                comparisonСharacteristics = new (string, string, string, string)[count];
                for (int i = 0; i < count; i++)
                    comparisonСharacteristics[i] = SplitString(sr.ReadLine());
            }
        }

        private static (string, string, string, string) SplitString(string val)
        {
            string table = string.Empty;
            string column = string.Empty;
            string value = string.Empty;
            int i = 0;
            while (val[i] != '.')
            {
                table += val[i];
                i++;
            }
            i++;
            while (val[i] != ' ')
            {
                column += val[i];
                i++;
            }
            string sign = val[++i].ToString();
            i++;
            if (val[i] != ' ')
            {
                sign += val[i];
                i++;
            }
            while (i < val.Length)
            {
                value += val[i];
                i++;
            }
            return (table, column, sign, value);
        }
    }
}
